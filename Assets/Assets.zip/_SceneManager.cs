﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class _SceneManager : MonoBehaviour
{

    public InputField mainInputField;

    public void LoadLevel(string level)
    {
        _Parameters.Ground_prob = int.Parse(mainInputField.text);
        SceneManager.LoadScene(level);
    }
}
