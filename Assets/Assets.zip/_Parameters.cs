﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class _Parameters 
{
    static int ground_prob  = 0;

    public static int Ground_prob
    {
        get
        {
            return ground_prob;
        }
        set
        {
            ground_prob = value;
        }
    }

}
