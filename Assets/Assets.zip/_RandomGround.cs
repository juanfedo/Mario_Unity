﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class _RandomGround : MonoBehaviour
{
    public Transform brick;
    // Start is called before the first frame update
    void Start()
    {
        int prob = _Parameters.Ground_prob;
        print("Probabilidad desde el menu: " + prob.ToString());
        System.Random rnd = new System.Random();
        List<int> coord = new List<int>();
        for (int x = 0; x <= 30; x++)
        {
            for (int y = 0; y <= 7; y++)
                if (rnd.Next(1, 10) <= prob)
                    coord.Add(x * y);
        }
        Instantiate_Ground(Validate_Coord(coord));
    }


    List<int> Validate_Coord(List<int> coord)
    {
        coord.Sort();
        for (int i = 0; i < coord.Count; i += 2)
        {
            if (i < coord.Count - 1)
            {
                int temp = (coord[i + 1] - coord[i]);
                if (temp > 6)
                    coord.Add((coord[i + 1] + coord[i]) / 2);
            }
        }
        return coord;
    }

    void Instantiate_Ground(List<int> coord)
    {
        foreach (int x in coord)
        {
            Instantiate(brick, new Vector3(x + 0.5f, -5.5f, 0), Quaternion.identity);
            Instantiate(brick, new Vector3(x + 0.5f, -6.5f, 0), Quaternion.identity);
        }
    }

    public string stringToEdit = "Hello World";

    void OnGUI()
    {
        // Make a text field that modifies stringToEdit.
        stringToEdit = GUI.TextField(new Rect(10, 10, 200, 20), stringToEdit, 25);
    }

    // Update is called once per frame
    void Update()
    {

    }
}



